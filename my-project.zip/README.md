# CodeGraphContext Bundle

## Repository Information
- **Repository**: multiple
- **Exported**: 2026-06-01T05:01:15Z
- **CGC Version**: 0.1.0

## Statistics
- **Total Nodes**: 1,665
- **Total Edges**: 2,868
- **Files**: 31

### Nodes by Type
- Parameter: 707
- Function: 448
- Variable: 300
- Module: 114
- File: 31
- Class: 21
- Directory: 19
- Interface: 9
- ExternalClass: 7
- DbTable: 6
- Repository: 2
- Enum: 1

### Edges by Type
- CONTAINS: 1,354
- HAS_PARAMETER: 712
- CALLS: 482
- IMPORTS: 225
- WRITES: 42
- READS: 37
- INHERITS: 10
- MAPS_TO: 6

## Usage

Load this bundle with:
```bash
cgc load <bundle-file>.cgc
```

Or import into existing graph:
```bash
cgc import <bundle-file>.cgc
```
